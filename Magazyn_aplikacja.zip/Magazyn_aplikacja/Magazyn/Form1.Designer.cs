﻿namespace Magazyn
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_users = new Button();
            tabela = new DataGridView();
            button_client = new Button();
            button_products = new Button();
            button_delivery = new Button();
            button_package = new Button();
            add_btn = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)tabela).BeginInit();
            SuspendLayout();
            // 
            // button_users
            // 
            button_users.Location = new Point(12, 77);
            button_users.Name = "button_users";
            button_users.Size = new Size(131, 50);
            button_users.TabIndex = 0;
            button_users.Text = "Użytkownicy";
            button_users.UseVisualStyleBackColor = true;
            button_users.Click += button_users_Click;
            // 
            // tabela
            // 
            tabela.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tabela.Location = new Point(169, 201);
            tabela.Name = "tabela";
            tabela.Size = new Size(793, 388);
            tabela.TabIndex = 1;
            // 
            // button_client
            // 
            button_client.Location = new Point(12, 133);
            button_client.Name = "button_client";
            button_client.Size = new Size(131, 50);
            button_client.TabIndex = 2;
            button_client.Text = "Klienci";
            button_client.UseVisualStyleBackColor = true;
            button_client.Click += button_client_Click;
            // 
            // button_products
            // 
            button_products.Location = new Point(12, 189);
            button_products.Name = "button_products";
            button_products.Size = new Size(131, 50);
            button_products.TabIndex = 3;
            button_products.Text = "Produkty";
            button_products.UseVisualStyleBackColor = true;
            button_products.Click += button_products_Click;
            // 
            // button_delivery
            // 
            button_delivery.Location = new Point(12, 245);
            button_delivery.Name = "button_delivery";
            button_delivery.Size = new Size(131, 50);
            button_delivery.TabIndex = 4;
            button_delivery.Text = "Dostawy";
            button_delivery.UseVisualStyleBackColor = true;
            button_delivery.Click += button_delivery_Click;
            // 
            // button_package
            // 
            button_package.Location = new Point(12, 301);
            button_package.Name = "button_package";
            button_package.Size = new Size(131, 50);
            button_package.TabIndex = 5;
            button_package.Text = "Paczki";
            button_package.UseVisualStyleBackColor = true;
            button_package.Click += button_package_Click;
            // 
            // add_btn
            // 
            add_btn.Location = new Point(169, 141);
            add_btn.Name = "add_btn";
            add_btn.Size = new Size(152, 42);
            add_btn.TabIndex = 10;
            add_btn.Text = "Dodaj";
            add_btn.UseVisualStyleBackColor = true;
            add_btn.Click += add_btn_Click;
            // 
            // button1
            // 
            button1.Location = new Point(12, 21);
            button1.Name = "button1";
            button1.Size = new Size(131, 50);
            button1.TabIndex = 11;
            button1.Text = "Strona główna";
            button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1147, 601);
            Controls.Add(button1);
            Controls.Add(add_btn);
            Controls.Add(button_package);
            Controls.Add(button_delivery);
            Controls.Add(button_products);
            Controls.Add(button_client);
            Controls.Add(tabela);
            Controls.Add(button_users);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Magazyn";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)tabela).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button_users;
        private DataGridView tabela;
        private Button button_client;
        private Button button_products;
        private Button button_delivery;
        private Button button_package;
        private Button add_btn;
        private Button button1;
    }
}
